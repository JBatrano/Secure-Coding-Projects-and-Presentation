#include <iostream>
#include <limits>
#include <string>

int main() 
{
  std::cout << "Buffer Overflow Example" << std::endl;

  // TODO: The user can type more than 20 characters and overflow the buffer, resulting in account_number being replaced -
  //  even though it is a constant and the compiler buffer overflow checks are on.
  //  You need to modify this method to prevent buffer overflow without changing the account_order
  //  varaible, and its position in the declaration. It must always be directly before the variable used for input.

    const std::string account_number = "CharlieBrown42";
    char user_input[20];

    while (true) {
    std::cout << "Enter a value (max 19 characters): ";
    std::cin.getline(user_input, sizeof(user_input));

        if (std::cin.fail()) {
            std::cin.clear(); // Clear error flag
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Ignore rest of input
            std::cout << "Input was too long, only the first 19 characters were considered.\n";
            continue; // Ask for input again
        }

  std::cout << "You entered: " << user_input << std::endl;
  std::cout << "Account Number = " << account_number << std::endl;

        break; // Exit loop if input is successful
    }

    return 0;
}
